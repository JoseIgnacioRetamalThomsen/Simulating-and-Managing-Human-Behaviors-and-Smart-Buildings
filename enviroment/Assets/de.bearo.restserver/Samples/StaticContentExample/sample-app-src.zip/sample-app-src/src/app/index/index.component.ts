import {Component, OnInit} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Message, WebsocketService} from "../websocket.service";

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {

  spawnCubeResponse = "";
  destroyCubeResponse = "";
  receivedFromWS: string = "";

  constructor(private http: HttpClient, private socketService: WebsocketService) {
    socketService.messages.subscribe(msg => {
      let poss = " {x: " + msg.Position?.x.toFixed(3)
        + ", y: " + msg.Position?.y.toFixed(3)
        + ", z: " + msg.Position?.z.toFixed(3) + "}";

      this.receivedFromWS = "Server Time: " + msg.Time + " Cube position: " + poss;
    });
  }

  CallSpawnCube() {
    this.http.post("/api/spawn_cube", null).subscribe(resp => {
      this.spawnCubeResponse = resp.toString();
    });
  }

  CallDestroyCube() {
    this.http.post("/api/destroy_cube", null).subscribe(resp => {
      this.destroyCubeResponse = resp.toString();
    });
  }

  ngOnInit(): void {
  }

  sendWsCommand(command: string) {
    // @ts-ignore
    let cmd: Message = {
      Command: command
    }
    this.socketService.messages.next(cmd);
  }
}
